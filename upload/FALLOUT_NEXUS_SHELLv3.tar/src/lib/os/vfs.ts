// Virtual file system for the retro CLI OS.
// A simple in-memory tree of directories and files. Persisted to localStorage
// so the user's mkdir/rm/sketches survive reloads.

export type VNode =
  | { type: 'dir'; name: string; children: Record<string, VNode> }
  | { type: 'file'; name: string; content: string }

export type VFS = {
  root: VNode
}

const STORAGE_KEY = 'cli-os-vfs-v2'

function dir(name: string, children: Record<string, VNode> = {}): VNode {
  return { type: 'dir', name, children }
}
function file(name: string, content: string): VNode {
  return { type: 'file', name, content }
}

/** Seed filesystem with a flavorful starting tree. */
function seed(): VFS {
  return {
    root: dir('/', {
      home: dir('home', {
        user: dir('user', {
          'readme.txt': file(
            'readme.txt',
            [
              'NEXUS OS v3.1 — terminal CLI',
              '============================',
              '',
              'This is the general CLI for the NEXUS dashboard system.',
              'The brain API runs on port 7352 (GLM-5.2 primary).',
              '',
              'Type `help` for the full manual. Quick start:',
              '  status        — system overview (8 pillars)',
              '  agents        — agent roster',
              '  swarm         — workers + tasks',
              '  vault         — 5-track memory',
              '  governor      — decisions + thresholds',
              '  tokens        — budget + pools',
              '  models        — model registry',
              '  doctor        — full diagnostic',
              '  ls /nexus     — governance filesystem',
              '',
              'Governance first. Stay patched. — sysop',
            ].join('\n')
          ),
          '.profile': file(
            '.profile',
            '# auto-loaded on boot\nexport THEME=green\nexport CRT=on\nexport BRAIN=7352\n'
          ),
          sketches: dir('sketches', {
            'logo.txt': file(
              'logo.txt',
              '  ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗\n' +
                '  ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝\n' +
                '  ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗\n' +
                '  ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║\n' +
                '  ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║\n' +
                '  ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝\n'
            ),
          }),
          logs: dir('logs', {
            'boot.log': file(
              'boot.log',
              '[ok] brain api 7352 ........ LIVE\n[ok] governor kaiju v2.4 ..... mounted\n[ok] vault 5-track .......... mounted\n[ok] swarm foreman ......... online\n[ok] model relay ............ quota_aware\n[ok] vfs loaded\n'
            ),
          }),
        }),
      }),
      etc: dir('etc', {
        'os-release': file(
          'os-release',
          'NAME="NEXUS OS"\nVERSION="3.1 (Phosphor)"\nBRAIN_PORT=7352\nPRIMARY_MODEL=GLM-5.2\nHOME=/home/user\n'
        ),
        motd: file('motd', 'Governance first. Every action is proposal-bound, test-gated, provenance-tracked.\n'),
      }),
      music: dir('music', {
        'INDEX': file(
          'INDEX',
          [
            'citysleep    - 02:14  ambient',
            'neonrain     - 01:48  synthwave',
            'ghostmode    - 02:30  darkwave',
            'pingu        - 01:12  chiptune',
            'deepdive     - 03:05  ambient',
          ].join('\n')
        ),
      }),
      bin: dir('bin', {
        'sh.sym': file('sh.sym', '-> /kernel/shell'),
      }),
    }),
  }
}

export function createVFS(): VFS {
  if (typeof window === 'undefined') return seed()
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as VFS
      if (parsed && parsed.root) return parsed
    }
  } catch {
    /* ignore corrupt storage */
  }
  const fresh = seed()
  persist(fresh)
  return fresh
}

export function persist(vfs: VFS) {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(vfs))
  } catch {
    /* quota / private mode */
  }
}

export function resetVFS(): VFS {
  const fresh = seed()
  persist(fresh)
  return fresh
}

/** Split a path into normalized segments. Handles absolute & relative, '.', '..'. */
export function normalizePath(path: string, cwd: string): string[] {
  let parts: string[]
  if (path.startsWith('/')) {
    parts = path.split('/')
  } else {
    parts = [...cwd.split('/').filter(Boolean), ...path.split('/')]
  }
  const out: string[] = []
  for (const p of parts) {
    if (p === '' || p === '.') continue
    if (p === '..') out.pop()
    else out.push(p)
  }
  return out
}

/** Resolve a path to a VNode, or null if not found. */
export function resolve(vfs: VFS, path: string, cwd: string): VNode | null {
  const segs = normalizePath(path, cwd)
  let node: VNode = vfs.root
  for (const seg of segs) {
    if (node.type !== 'dir') return null
    const next = node.children[seg]
    if (!next) return null
    node = next
  }
  return node
}

/** Resolve to a directory or null. */
export function resolveDir(vfs: VFS, path: string, cwd: string): Extract<VNode, { type: 'dir' }> | null {
  const node = resolve(vfs, path, cwd)
  if (node && node.type === 'dir') return node
  return null
}

/** Return the absolute path string for a normalized path. */
export function absPath(path: string, cwd: string): string {
  const segs = normalizePath(path, cwd)
  return '/' + segs.join('/')
}

/** Create a directory (mkdir -p style for the last segment only; parent must exist). */
export function mkdir(
  vfs: VFS,
  path: string,
  cwd: string
): { ok: true; path: string } | { ok: false; error: string } {
  const segs = normalizePath(path, cwd)
  if (segs.length === 0) return { ok: false, error: 'cannot create root' }
  const parentSegs = segs.slice(0, -1)
  const name = segs[segs.length - 1]
  let node: VNode = vfs.root
  for (const seg of parentSegs) {
    if (node.type !== 'dir') return { ok: false, error: `not a directory: ${seg}` }
    const next = node.children[seg]
    if (!next) return { ok: false, error: `no such directory: ${seg}` }
    node = next
  }
  if (node.type !== 'dir') return { ok: false, error: 'not a directory' }
  if (node.children[name]) {
    return { ok: false, error: `already exists: ${name}` }
  }
  node.children[name] = dir(name)
  persist(vfs)
  return { ok: true, path: '/' + segs.join('/') }
}

/** Remove a file or directory (rm -rf style for dirs). */
export function rm(
  vfs: VFS,
  path: string,
  cwd: string
): { ok: true; path: string } | { ok: false; error: string } {
  const segs = normalizePath(path, cwd)
  if (segs.length === 0) return { ok: false, error: 'refusing to remove root' }
  const parentSegs = segs.slice(0, -1)
  const name = segs[segs.length - 1]
  let node: VNode = vfs.root
  for (const seg of parentSegs) {
    if (node.type !== 'dir') return { ok: false, error: `not a directory: ${seg}` }
    const next = node.children[seg]
    if (!next) return { ok: false, error: `no such directory: ${seg}` }
    node = next
  }
  if (node.type !== 'dir') return { ok: false, error: 'not a directory' }
  if (!node.children[name]) return { ok: false, error: `no such file: ${name}` }
  delete node.children[name]
  persist(vfs)
  return { ok: true, path: '/' + segs.join('/') }
}

/** Write/create a file (overwrites). Returns full path. */
export function writeFile(
  vfs: VFS,
  path: string,
  cwd: string,
  content: string
): { ok: true; path: string } | { ok: false; error: string } {
  const segs = normalizePath(path, cwd)
  if (segs.length === 0) return { ok: false, error: 'cannot write to root' }
  const parentSegs = segs.slice(0, -1)
  const name = segs[segs.length - 1]
  let node: VNode = vfs.root
  for (const seg of parentSegs) {
    if (node.type !== 'dir') return { ok: false, error: `not a directory: ${seg}` }
    const next = node.children[seg]
    if (!next) return { ok: false, error: `no such directory: ${seg}` }
    node = next
  }
  if (node.type !== 'dir') return { ok: false, error: 'not a directory' }
  node.children[name] = file(name, content)
  persist(vfs)
  return { ok: true, path: '/' + segs.join('/') }
}
