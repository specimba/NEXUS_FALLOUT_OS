import type { ThemeId, TermLine } from './types'
import type { VFS } from './vfs'
import { absPath, resolve, resolveDir, mkdir, rm } from './vfs'
import { LIBRARY, findSong, formatTime, songDurationSec, type Song } from './music'
import { THEME_LIST } from './themes'
import { NEXUS_COMMANDS } from './nexus-commands'

export type CommandContext = {
  vfs: VFS
  cwd: string
  setCwd: (p: string) => void
  setTheme: (id: ThemeId) => void
  toggleCrt: () => void
  setCrt: (v: boolean) => void
  isCrtOn: () => boolean
  setSound: (v: boolean) => void
  isSoundOn: () => boolean
  openMode: (mode: 'paint' | 'chat') => void
  playSong: (song: Song) => void
  stopSong: () => void
  isPlaying: () => boolean
  nowPlaying: () => Song | null
  clear: () => void
  history: () => string[]
  resetVfs: () => void
  /** Push a line to the scrollback immediately (for streaming/live commands). */
  pushLine: (line: OutLine) => void
  /** Register a stop function for the currently-running live command (Ctrl+C / q stops it). */
  registerStop: (fn: () => void) => void
}

export type OutLine = { text: string; kind?: TermLine['kind'] }

export type CommandResult = {
  lines: OutLine[]
  /** If set, the terminal opens a fullscreen less-style viewer with this text. */
  openManual?: string
  /** Suppress the prompt echo of the command (used by clear). */
  silent?: boolean
  /** If true, the command runs in the background pushing lines via ctx.pushLine;
   *  the terminal stays "busy" until ctx.registerStop's fn is invoked (Ctrl+C / q). */
  live?: boolean
}

export type CommandDef = {
  name: string
  summary: string
  help: string
  run: (args: string[], ctx: CommandContext) => CommandResult | Promise<CommandResult>
  /** Tab-complete the args at a given index. Returns candidate strings. */
  complete?: (args: string[], argIndex: number, ctx: CommandContext) => string[]
}

const FS_COMMANDS = ['ls', 'cd', 'cat', 'mkdir', 'rm', 'rmdir']

/** List child names of a directory for completion, preserving the typed prefix. */
function completePath(prefix: string, ctx: CommandContext): string[] {
  let dirPart: string
  let namePrefix: string
  if (prefix.includes('/')) {
    const idx = prefix.lastIndexOf('/')
    dirPart = prefix.slice(0, idx + 1)
    namePrefix = prefix.slice(idx + 1)
  } else {
    dirPart = ''
    namePrefix = prefix
  }
  const target = resolveDir(ctx.vfs, dirPart || '.', ctx.cwd)
  if (!target) return []
  return Object.keys(target.children)
    .filter((n) => n.startsWith(namePrefix))
    .map((n) => {
      const node = target.children[n]
      return node.type === 'dir' ? dirPart + n + '/' : dirPart + n
    })
}

function ls(args: string[], ctx: CommandContext): CommandResult {
  const target = args[0] ? args[0] : '.'
  const node = resolve(ctx.vfs, target, ctx.cwd)
  if (!node) return { lines: [{ text: `ls: ${target}: no such file or directory`, kind: 'error' }] }
  if (node.type === 'file') return { lines: [{ text: node.name }] }
  const entries = Object.values(node.children).sort((a, b) =>
    a.name.localeCompare(b.name)
  )
  if (entries.length === 0) return { lines: [] }
  // Format in columns: dirs get a trailing /, files a size hint.
  const named = entries.map((e) => ({
    name: e.type === 'dir' ? e.name + '/' : e.name,
    isDir: e.type === 'dir',
    size: e.type === 'file' ? e.content.length : 0,
  }))
  // simple columnar layout
  const maxLen = Math.max(...named.map((n) => n.name.length), 1)
  const cols = Math.max(1, Math.floor(72 / (maxLen + 2)))
  const lines: OutLine[] = []
  for (let i = 0; i < named.length; i += cols) {
    const row = named.slice(i, i + cols)
    lines.push({ text: row.map((n) => n.name.padEnd(maxLen + 2)).join('') })
  }
  return { lines }
}

function cd(args: string[], ctx: CommandContext): CommandResult {
  const target = args[0] || '/home/user'
  const node = resolve(ctx.vfs, target, ctx.cwd)
  if (!node) return { lines: [{ text: `cd: ${target}: no such file or directory`, kind: 'error' }] }
  if (node.type !== 'dir') return { lines: [{ text: `cd: ${target}: not a directory`, kind: 'error' }] }
  const p = absPath(target, ctx.cwd)
  ctx.setCwd(p)
  return { lines: [] }
}

function cat(args: string[], ctx: CommandContext): CommandResult {
  if (args.length === 0) return { lines: [{ text: 'cat: missing file operand', kind: 'error' }] }
  const out: OutLine[] = []
  for (const a of args) {
    const node = resolve(ctx.vfs, a, ctx.cwd)
    if (!node) {
      out.push({ text: `cat: ${a}: no such file or directory`, kind: 'error' })
      continue
    }
    if (node.type === 'dir') {
      out.push({ text: `cat: ${a}: is a directory`, kind: 'error' })
      continue
    }
    out.push({ text: node.content.replace(/\n$/, '') })
  }
  return { lines: out }
}

function mkdirCmd(args: string[], ctx: CommandContext): CommandResult {
  if (args.length === 0) return { lines: [{ text: 'mkdir: missing operand', kind: 'error' }] }
  const out: OutLine[] = []
  for (const a of args) {
    const res = mkdir(ctx.vfs, a, ctx.cwd)
    if (!res.ok) out.push({ text: `mkdir: ${res.error}`, kind: 'error' })
  }
  return { lines: out }
}

function rmCmd(args: string[], ctx: CommandContext): CommandResult {
  const flags = args.filter((a) => a.startsWith('-'))
  const paths = args.filter((a) => !a.startsWith('-'))
  const recursive = flags.some((f) => f.includes('r') || f.includes('R'))
  if (paths.length === 0) return { lines: [{ text: 'rm: missing operand', kind: 'error' }] }
  const out: OutLine[] = []
  for (const p of paths) {
    const node = resolve(ctx.vfs, p, ctx.cwd)
    if (!node) {
      out.push({ text: `rm: ${p}: no such file or directory`, kind: 'error' })
      continue
    }
    if (node.type === 'dir' && !recursive) {
      out.push({ text: `rm: ${p}: is a directory (use -r)`, kind: 'error' })
      continue
    }
    const res = rm(ctx.vfs, p, ctx.cwd)
    if (!res.ok) out.push({ text: `rm: ${res.error}`, kind: 'error' })
  }
  return { lines: out }
}

function playCmd(args: string[], ctx: CommandContext): CommandResult {
  const sub = args[0]
  if (!sub || sub === 'list') {
    const lines: OutLine[] = [
      { text: 'MUSIC LIBRARY', kind: 'system' },
      { text: '  id            title          time   genre' },
    ]
    for (const s of LIBRARY) {
      lines.push({
        text: `  ${s.id.padEnd(13)} ${s.title.padEnd(14)} ${formatTime(songDurationSec(s)).padEnd(6)} ${s.genre}`,
      })
    }
    lines.push({ text: '', kind: 'dim' })
    const np = ctx.nowPlaying()
    if (np && ctx.isPlaying()) {
      lines.push({ text: `now playing: ${np.title} — ${np.artist}`, kind: 'success' })
    } else {
      lines.push({ text: 'usage: play <song-id>   |   play stop', kind: 'dim' })
    }
    return { lines }
  }
  if (sub === 'stop') {
    ctx.stopSong()
    return { lines: [{ text: 'playback stopped.', kind: 'dim' }] }
  }
  const song = findSong(sub)
  if (!song) {
    return { lines: [{ text: `play: no such song '${sub}'. try 'play list'.`, kind: 'error' }] }
  }
  ctx.playSong(song)
  return {
    lines: [
      { text: `▶ playing: ${song.title} — ${song.artist}  [${song.genre}]`, kind: 'success' },
      { text: `  ${formatTime(0)} / ${formatTime(songDurationSec(song))}`, kind: 'dim' },
    ],
  }
}

async function weatherCmd(args: string[], ctx: CommandContext): Promise<CommandResult> {
  const city = args.join(' ').trim() || 'Neon City'
  // Use relative path; same Next.js app on port 3000 (no XTransformPort needed).
  const url = `/api/weather?city=${encodeURIComponent(city)}`
  try {
    const res = await fetch(url)
    if (!res.ok) throw new Error(`http ${res.status}`)
    const w = (await res.json()) as {
      city: string
      fetchedAt: string
      tempC: number
      feelsLikeC: number
      condition: string
      humidity: number
      windKph: number
      windDir: string
      visibilityKm: number
      pressureHpa: number
      uvIndex: number
      sunrise: string
      sunset: string
      forecast: { day: string; cond: string; hi: number; lo: number }[]
    }
    const time = new Date(w.fetchedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    const lines: OutLine[] = [
      { text: `┌─ WEATHER UPLINK ─ ${w.city.toUpperCase()} ────`, kind: 'system' },
      { text: `│  ${w.condition}, ${w.tempC}°C (feels ${w.feelsLikeC}°C)` },
      { text: `│  humidity ${w.humidity}%   wind ${w.windKph} kph ${w.windDir}` },
      { text: `│  pressure ${w.pressureHpa} hPa   visibility ${w.visibilityKm} km   uv ${w.uvIndex}` },
      { text: `│  sunrise ${w.sunrise}   sunset ${w.sunset}   @ ${time}` },
      { text: `│` },
      { text: `│  FORECAST` },
      ...w.forecast.map((f) => ({ text: `│   ${f.day.padEnd(8)} ${f.cond.padEnd(14)} hi ${f.hi}°  lo ${f.lo}°` })),
      { text: `└──────────────────────────────────`, kind: 'system' },
    ]
    return { lines }
  } catch (e) {
    return { lines: [{ text: `weather: uplink failed (${(e as Error).message})`, kind: 'error' }] }
  }
}

function themeCmd(args: string[], ctx: CommandContext): CommandResult {
  if (args.length === 0) {
    return {
      lines: [
        { text: 'usage: theme <amber|green|white>', kind: 'dim' },
        { text: `available: ${THEME_LIST.join(', ')}`, kind: 'dim' },
      ],
    }
  }
  const id = args[0].toLowerCase() as ThemeId
  if (!THEME_LIST.includes(id)) {
    return { lines: [{ text: `theme: unknown theme '${args[0]}'. options: ${THEME_LIST.join(', ')}`, kind: 'error' }] }
  }
  ctx.setTheme(id)
  return { lines: [{ text: `theme set: ${id}`, kind: 'success' }] }
}

function crtCmd(args: string[], ctx: CommandContext): CommandResult {
  if (args.length === 0) {
    ctx.toggleCrt()
  } else {
    ctx.setCrt(args[0] === 'on')
  }
  return { lines: [{ text: `scanlines: ${ctx.isCrtOn() ? 'on' : 'off'}`, kind: 'dim' }] }
}

function soundCmd(args: string[], ctx: CommandContext): CommandResult {
  if (args.length === 0) {
    return { lines: [{ text: `key sounds: ${ctx.isSoundOn() ? 'on' : 'off'}  (usage: sound on|off)`, kind: 'dim' }] }
  }
  ctx.setSound(args[0] === 'on')
  return { lines: [{ text: `key sounds: ${ctx.isSoundOn() ? 'on' : 'off'}`, kind: 'success' }] }
}

const MANUAL = `
NEXUS OS v3.1 — TERMINAL MANUAL  (fallout-shell 1.06)
=====================================================

NEXUS OS is a governed multi-agent operating system. This terminal is the
general CLI for the dashboard: query the brain (port 7352), inspect agents,
the vault, the governor, the swarm, token budgets, models, and more. Every
governance command hits the local /api/nexus/* brain.

NAVIGATION & HISTORY
  Up / Down          recall previous / next command
  Left / Right       move cursor within the line
  Tab                complete the current token (ghost text preview)
  Enter              execute the line
  Ctrl+L             clear the screen
  Ctrl+C             copy selection (if text selected) or cancel current line
  Ctrl+V             paste from clipboard
  Ctrl+R             reverse search command history

FILE SYSTEM
  ls [path]          list directory contents (try: ls /nexus)
  cd [path]          change directory (default: /home/user)
  cat <file>...      print file contents (try: cat /nexus/governor/constitution)
  mkdir <name>...    create a directory
  rm [-r] <path>...  remove a file (use -r for directories)
  pwd                print working directory
  echo <text>        print text

NEXUS GOVERNANCE  (the core of this CLI)
  status [short]     system overview — 8 pillars, agents, tokens, brain
  brain              brain API status (port 7352)
  top                LIVE status refresh every 2s (q/Ctrl+C to stop)
  tail [n]           LIVE log stream — last n + new events (q/Ctrl+C to stop)
  ask <question>     ask the NEXUS assistant (LLM with live governance context)
  agents [name]      agent roster, or one agent's detail
  agents spawn ...   spawn a new agent (also: spawn <name> <type> <domain>)
  swarm [sub]        workers + tasks. sub: tasks | probe | dispatch <type> <prompt>
  vault [track]      5-track memory. tracks: EVENT TRUST CAP FAIL GOV
  governor [sub]     decisions + thresholds. sub: threshold | appeal <id>
  appeal <id> <r>    appeal a governor decision
  trust [agent]      trust engine + CDR matrix (0=NOMINAL … 5=HARDWALL)
  trust-update <a>   adjust an agent's trust: trust-update <agent> <+/-delta>
  tokens             token guard budget + ECO/FAST/PREMIUM pools
  cost               spend intelligence + burn rate + insights
  models [flags]     model registry. flags: --free --tier <t> --healthy
  gmr [flags]        alias for models
  relay              model relay gateway status
  compliance         constitutional rules CR-001..CR-006
  proposals [sub]    governance proposals. sub: approve <id> | reject <id>
  propose <t> <r> <title>   create a proposal (type, risk LOW|MED|HIGH|CRIT)
  vap [verify]       VAP hash-linked audit chain
  logs [limit]       unified log feed
  ports              11 canonical ports
  doctor             nexusctl doctor — full system diagnostic
  scan               security findings

MULTIMEDIA & APPS
  play [list]        list the music library
  play <song>        play a song by id (prefix match ok)
  play stop          stop playback
  paint              open the ASCII paint editor
  chat               open the mesh chat client
  weather [city]     fetch weather for a (fictional) city

SYSTEM
  theme <amber|green|white>   switch phosphor color (200ms fade)
  crt [on|off]                toggle CRT scanline overlay
  sound [on|off]              toggle mechanical key clicks
  neofetch                    NEXUS system banner
  whoami                      print current user
  date                        print current date/time
  history                     list command history
  help [command]              show this manual (or a command's detail)
  reset                       restore the filesystem to factory state
  clear                       clear the screen

TIPS
  • Start with 'status' for the full picture, then 'doctor'.
  • 'swarm dispatch research analyze the latest arxiv batch' routes a task.
  • 'vault GOV' filters the governance track; 'vap verify' checks integrity.
  • 'cd /nexus' then 'ls' explores the governance filesystem.
  • In 'paint': arrows move, space paints, 1-0 pick a brush, q quits.
  • In 'chat': Tab switches contacts, Enter sends, :q quits.

Governance first. Every action is proposal-bound, test-gated, provenance-tracked.
Stay patched. — sysop
`.trim()

function helpCmd(args: string[]): CommandResult {
  if (args[0]) {
    const def = COMMANDS[args[0]]
    if (!def) return { lines: [{ text: `help: no such command: ${args[0]}`, kind: 'error' }] }
    return {
      lines: [
        { text: `NAME`, kind: 'system' },
        { text: `  ${def.name} — ${def.summary}` },
        { text: `` },
        { text: `SYNOPSIS`, kind: 'system' },
        { text: `  ${def.help}` },
      ],
    }
  }
  return { lines: [], openManual: MANUAL }
}

function neofetchCmd(ctx: CommandContext): CommandResult {
  const np = ctx.nowPlaying()
  const lines: OutLine[] = [
    { text: '    ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗     nexus@os' },
    { text: '    ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝     ----------------' },
    { text: '    ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗     OS: NEXUS OS v3.1 (Phosphor)' },
    { text: '    ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║     Shell: fallout-sh 1.06' },
    { text: '    ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║     Brain: 7352 LIVE · GLM-5.2' },
    { text: '    ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝     CRT: ' + (ctx.isCrtOn() ? 'on' : 'off') + ' · Keys: ' + (ctx.isSoundOn() ? 'clicky' : 'silent') },
    { text: '                                                    Uptime: ' + uptimeStr() },
    { text: '                                                    Tracks: ' + LIBRARY.length + ' songs · 5 agents · 18 models' },
  ]
  if (np && ctx.isPlaying()) lines.push({ text: `                                                    Now playing: ${np.title}`, kind: 'success' })
  lines.push({ text: '', kind: 'dim' })
  lines.push({ text: '    "Governance first. Proposal-bound. Provenance-tracked."', kind: 'dim' })
  return { lines }
}

const BOOT_TIME = Date.now()
function uptimeStr(): string {
  const s = Math.floor((Date.now() - BOOT_TIME) / 1000)
  const m = Math.floor(s / 60)
  const sec = s % 60
  if (m === 0) return `${sec}s`
  const h = Math.floor(m / 60)
  if (h === 0) return `${m}m ${sec}s`
  return `${h}h ${m % 60}m ${sec}s`
}

export const COMMANDS: Record<string, CommandDef> = {
  help: {
    name: 'help',
    summary: 'show the user manual',
    help: 'help [command]   — show the full manual, or detail for one command',
    run: (a) => helpCmd(a),
  },
  ls: {
    name: 'ls',
    summary: 'list directory contents',
    help: 'ls [path]',
    run: ls,
    complete: (a, i, ctx) => completePath(a[i] || '', ctx),
  },
  cd: {
    name: 'cd',
    summary: 'change directory',
    help: 'cd [path]   (default: /home/user)',
    run: cd,
    complete: (a, i, ctx) => completePath(a[i] || '', ctx),
  },
  cat: {
    name: 'cat',
    summary: 'print file contents',
    help: 'cat <file> [file...]',
    run: cat,
    complete: (a, i, ctx) => completePath(a[i] || '', ctx),
  },
  mkdir: {
    name: 'mkdir',
    summary: 'create a directory',
    help: 'mkdir <name> [name...]',
    run: mkdirCmd,
    complete: (a, i, ctx) => completePath(a[i] || '', ctx),
  },
  rm: {
    name: 'rm',
    summary: 'remove files or directories',
    help: 'rm [-r] <path> [path...]',
    run: rmCmd,
    complete: (a, i, ctx) => completePath(a[i] || '', ctx),
  },
  rmdir: {
    name: 'rmdir',
    summary: 'remove a directory',
    help: 'rmdir <path>',
    run: (a, ctx) => rmCmd(['-r', ...a], ctx),
    complete: (a, i, ctx) => completePath(a[i] || '', ctx),
  },
  pwd: {
    name: 'pwd',
    summary: 'print working directory',
    help: 'pwd',
    run: (_a, ctx) => ({ lines: [{ text: ctx.cwd }] }),
  },
  echo: {
    name: 'echo',
    summary: 'print text',
    help: 'echo <text>',
    run: (a) => ({ lines: [{ text: a.join(' ') }] }),
  },
  play: {
    name: 'play',
    summary: 'play music from the library',
    help: 'play [list|stop|<song-id>]',
    run: playCmd,
    complete: (a, _i, _ctx) => {
      if (!a[0]) return ['list', 'stop', ...LIBRARY.map((s) => s.id)]
      if (['list', 'stop'].includes(a[0])) return []
      return LIBRARY.map((s) => s.id).filter((id) => id.startsWith(a[0].toLowerCase()))
    },
  },
  paint: {
    name: 'paint',
    summary: 'open the ASCII paint editor',
    help: 'paint',
    run: (_a, ctx) => {
      ctx.openMode('paint')
      return { lines: [] }
    },
  },
  chat: {
    name: 'chat',
    summary: 'open the mesh chat client',
    help: 'chat',
    run: (_a, ctx) => {
      ctx.openMode('chat')
      return { lines: [] }
    },
  },
  weather: {
    name: 'weather',
    summary: 'fetch weather for a (fictional) city',
    help: 'weather [city]   (default: Neon City)',
    run: weatherCmd,
  },
  theme: {
    name: 'theme',
    summary: 'switch phosphor theme',
    help: 'theme <amber|green|white>',
    run: themeCmd,
    complete: (a, _i) => THEME_LIST.filter((t) => t.startsWith((a[0] || '').toLowerCase())),
  },
  crt: {
    name: 'crt',
    summary: 'toggle CRT scanlines',
    help: 'crt [on|off]',
    run: crtCmd,
    complete: (a) => ['on', 'off'].filter((o) => o.startsWith(a[0] || '')),
  },
  sound: {
    name: 'sound',
    summary: 'toggle mechanical key clicks',
    help: 'sound [on|off]',
    run: soundCmd,
    complete: (a) => ['on', 'off'].filter((o) => o.startsWith(a[0] || '')),
  },
  clear: {
    name: 'clear',
    summary: 'clear the screen',
    help: 'clear',
    run: (_a, ctx) => {
      ctx.clear()
      return { lines: [], silent: true }
    },
  },
  cls: {
    name: 'cls',
    summary: 'clear the screen',
    help: 'cls',
    run: (_a, ctx) => {
      ctx.clear()
      return { lines: [], silent: true }
    },
  },
  neofetch: {
    name: 'neofetch',
    summary: 'system summary banner',
    help: 'neofetch',
    run: (_a, ctx) => neofetchCmd(ctx),
  },
  about: {
    name: 'about',
    summary: 'system summary banner',
    help: 'about',
    run: (_a, ctx) => neofetchCmd(ctx),
  },
  whoami: {
    name: 'whoami',
    summary: 'print current user',
    help: 'whoami',
    run: () => ({ lines: [{ text: 'user' }] }),
  },
  date: {
    name: 'date',
    summary: 'print current date and time',
    help: 'date',
    run: () => ({ lines: [{ text: new Date().toString() }] }),
  },
  history: {
    name: 'history',
    summary: 'list command history',
    help: 'history',
    run: (_a, ctx) => {
      const h = ctx.history()
      return { lines: h.map((cmd, i) => ({ text: `  ${(i + 1).toString().padStart(3)}  ${cmd}`, kind: 'dim' as const })) }
    },
  },
  reset: {
    name: 'reset',
    summary: 'restore filesystem to factory state',
    help: 'reset',
    run: (_a, ctx) => {
      ctx.resetVfs()
      return { lines: [{ text: 'filesystem reset to factory state.', kind: 'success' }] }
    },
  },
  watch: {
    name: 'watch',
    summary: 're-run a command every N seconds (default 3s). q/Ctrl+C to stop.',
    help: 'watch <interval-sec> <command...>   e.g. watch 2 status',
    run: async (args, ctx) => {
      // parse optional interval
      let interval = 3
      let rest: string[]
      const n = parseInt(args[0], 10)
      if (!Number.isNaN(n) && args.length > 1) {
        interval = Math.max(1, Math.min(60, n))
        rest = args.slice(1)
      } else {
        rest = args
      }
      if (rest.length === 0) {
        return { lines: [{ text: 'usage: watch [interval-sec] <command...>   e.g. watch 2 status', kind: 'error' }] }
      }
      const subName = rest[0]
      const subArgs = rest.slice(1)
      const subDef = COMMANDS[subName]
      if (!subDef) {
        return { lines: [{ text: `watch: unknown command '${subName}'`, kind: 'error' }] }
      }
      if (subName === 'watch' || subName === 'top' || subName === 'tail') {
        return { lines: [{ text: `watch: cannot nest live command '${subName}'`, kind: 'error' }] }
      }
      let stopped = false
      const stop = () => {
        stopped = true
        ctx.pushLine({ text: `└─ watch stopped`, kind: 'system' })
      }
      ctx.registerStop(stop)
      const runOnce = async () => {
        if (stopped) return
        ctx.pushLine({ text: `┌─ watch ${subName} ${subArgs.join(' ')}  — ${new Date().toISOString().slice(11, 19)}  (q to stop)`, kind: 'system' })
        try {
          const res = await subDef.run(subArgs, ctx)
          if (res.lines.length) ctx.pushLine({ text: res.lines.map((l) => '│  ' + l.text).join('\n') })
          if (res.openManual) {
            ctx.pushLine({ text: '│  (command opens a viewer — skipped in watch mode)', kind: 'dim' })
          }
        } catch (e) {
          ctx.pushLine({ text: `│  error: ${(e as Error).message}`, kind: 'error' })
        }
        ctx.pushLine({ text: '│', kind: 'dim' })
      }
      await runOnce()
      const timer = setInterval(runOnce, interval * 1000)
      ctx.registerStop(() => {
        stop()
        clearInterval(timer)
      })
      return { lines: [], live: true }
    },
    complete: (a, _i, _ctx) => {
      if (a.length <= 1) return COMMAND_NAMES.filter((c) => !['watch', 'top', 'tail', 'paint', 'chat', 'help'].includes(c))
      return []
    },
  },
  // ── NEXUS OS governance commands (query the local brain on /api/nexus/*) ──
  ...NEXUS_COMMANDS,
}

export const COMMAND_NAMES = Object.keys(COMMANDS).sort()

/** Tokenize a command line into [name, ...args], respecting simple quotes. */
export function tokenize(line: string): string[] {
  const tokens: string[] = []
  let cur = ''
  let quote: string | null = null
  for (let i = 0; i < line.length; i++) {
    const c = line[i]
    if (quote) {
      if (c === quote) quote = null
      else cur += c
    } else if (c === '"' || c === "'") {
      quote = c
    } else if (c === ' ' || c === '\t') {
      if (cur) {
        tokens.push(cur)
        cur = ''
      }
    } else {
      cur += c
    }
  }
  if (cur) tokens.push(cur)
  return tokens
}

export { FS_COMMANDS, MANUAL }
