// Shared types for the retro CLI OS.
// All "mode" sub-apps (paint, chat) implement ModeProps so the terminal can
// mount them fullscreen and return to the shell on exit.

export type ThemeId = 'amber' | 'green' | 'white'

export type Theme = {
  id: ThemeId
  name: string
  /** background color */
  bg: string
  /** foreground text color */
  fg: string
  /** text-shadow glow color */
  glow: string
  /** faded color for ghost text / dim lines */
  dim: string
}

export type ModeProps = {
  theme: Theme
  /** Return to the shell. Optional lines are printed to the terminal buffer. */
  onExit: (output?: string[]) => void
  /** Save a file into the virtual FS (resolved relative to cwd). Returns full saved path. */
  saveFile?: (filename: string, content: string) => string
}

/** A single rendered line/block in the terminal scrollback. */
export type TermLine = {
  id: number
  /** raw text (may contain newlines) */
  text: string
  /** visual variant */
  kind?: 'input' | 'output' | 'error' | 'success' | 'system' | 'dim'
}
