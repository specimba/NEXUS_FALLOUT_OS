// NEXUS OS brain data shapes. The brain kernel (src/lib/nexus/brain.ts) produces
// these; the /api/nexus/* routes return them; the terminal CLI renders them.

export type NexusStatus = 'LIVE' | 'DEGRADED' | 'MOCK' | 'OFFLINE'

export interface Pillar {
  name: string
  health: number
  status: 'OPERATIONAL' | 'DEGRADED' | 'OFFLINE'
}

export interface Agent {
  id: string
  name: string
  role: string
  type: 'worker' | 'coordinator' | 'specialist'
  status: 'idle' | 'busy' | 'error' | 'offline'
  domain: 'code' | 'reason' | 'research' | 'fast' | 'sec'
  trustScore: number
  totalTokens: number
  tasksDone: number
  tasksFailed: number
  lastActive: string
}

export interface VaultEntry {
  id: string
  track: 'EVENT' | 'TRUST' | 'CAP' | 'FAIL' | 'GOV'
  key: string
  value: string
  score: number
  agent: string
  ts: string
}

export interface GovernorDecision {
  id: string
  agent: string
  action: string
  scope: 'SELF' | 'PROJECT' | 'CROSS' | 'SYSTEM' | 'CRIT'
  impact: 'LOW' | 'MED' | 'HIGH' | 'CRIT'
  decision: 'ALLOW' | 'DENY' | 'HOLD'
  reason: string
  trustAtTime: number
  ts: string
}

export interface SwarmWorker {
  id: string
  name: string
  status: 'idle' | 'busy' | 'error' | 'offline'
  trust: number
  tasksDone: number
  currentTask: string | null
}

export interface SwarmTask {
  id: string
  type: 'research' | 'code' | 'analysis' | 'governance' | 'chat' | 'embedding'
  status: 'queued' | 'running' | 'completed' | 'failed'
  priority: 'LOW' | 'MED' | 'HIGH' | 'CRIT'
  assignedTo: string | null
}

export interface ModelEntry {
  name: string
  provider: string
  tier: 'reasoning' | 'balanced' | 'fast' | 'free'
  domain: string
  health: number
  latencyMs: number
  costPer1k: number
  isFree: boolean
  isActive: boolean
  successRate: number
  totalCalls: number
}

export interface PortEntry {
  port: number
  service: string
  protocol: string
  status: NexusStatus
}

export interface ComplianceRule {
  id: string
  title: string
  status: 'PASS' | 'WARN' | 'FAIL'
  violations: number
}

export interface Proposal {
  id: string
  agent: string
  type: string
  title: string
  riskLevel: 'LOW' | 'MED' | 'HIGH' | 'CRIT'
  status: 'pending' | 'approved' | 'rejected' | 'held'
  ts: string
}

export interface VapEntry {
  id: string
  hash: string
  prevHash: string
  action: string
  actor: string
  ts: string
}

export interface LogEntry {
  ts: string
  level: 'info' | 'warn' | 'error' | 'debug' | 'success'
  source: string
  message: string
}

export interface WikiPage {
  id: string
  title: string
  category: string
  summary: string
  body: string
  updated: string
  reads: number
}
