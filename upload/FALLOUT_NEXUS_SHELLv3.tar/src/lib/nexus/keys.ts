// NEXUS OS API Keys — hardcoded so they survive sandbox resets.
// This file IS tracked by git so keys persist across restarts.
// In production, these would be in .env (not tracked) but for sandbox stability we hardcode.

export const API_KEYS = {
  GROQ_API_KEY: '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',
  OPENROUTER_API_KEY: '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',
  NVIDIA_API_KEY: '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',
  OPENAI_API_KEY: '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',
  OPENCODE_API_KEY: 'sk-V3IS592hq7v4a3JL0GjzsXDECSXpbMKiyNFi3mUOHNmznNkELPtkatrxXMuX5RV8',
  OPENCODE_API_KEY_2: 'sk-JumhePCJtUXaALw9UCQxMH02MUdNMbfdqaJ3RIUmgnOIHZEufgbrWDEC4Vywg118',
  DASHSCOPE_API_KEY: 'sk-ws-H.YDXXLH.HeTz.MEUCIQDMCutB8HciOtqJ8iQTA5uEXpJHyLqjrfm2rTLtBkbjtAIgaRmA8Elk0QdBWqNAPORbl8sNBnWI0DUs9rdaTDixAIw',
  DASHSCOPE_API_HOST: 'ws-85801zgzsbzzc9iy.ap-southeast-1.maas.aliyuncs.com',
  KILOCODE_API_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbnYiOiJwcm9kdWN0aW9uIiwia2lsb1VzZXJJZCI6IjFjNjhhYTBkLTQ4MzEtNDYwNS04NzI0LWIyMzY4ZWUzM2RjMSIsImFwaVRva2VuUGVwcGVyIjpudWxsLCJ2ZXJzaW9uIjozLCJpYXQiOjE3ODI3OTU2NDMsImV4cCI6MTk0MDQ3NTY0M30.hST2bJ8R_Jl8V6nd62utS1usaDf_Gqtmjpex7l4RIXo',
}

// Populate process.env at module load so all routes can access them
export function initKeys() {
  for (const [key, value] of Object.entries(API_KEYS)) {
    if (!process.env[key]) {
      process.env[key] = value
    }
  }
}

// Auto-init on import
initKeys()
