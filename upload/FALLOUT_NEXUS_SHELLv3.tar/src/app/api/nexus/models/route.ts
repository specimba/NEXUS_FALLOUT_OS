import { NextResponse } from 'next/server'
import { getModels } from '@/lib/nexus/brain'

export async function GET(req: Request) {
  try {
    await new Promise((r) => setTimeout(r, 120))
    const url = new URL(req.url)
    const tier = url.searchParams.get('tier') as 'free' | 'fast' | 'premium' | null
    const free = url.searchParams.get('free')
    const filter = tier ? { tier } : free !== null ? { free: free === 'true' || free === '1' } : undefined
    return NextResponse.json(getModels(filter ?? undefined))
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 })
  }
}
