import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const mono = JetBrains_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "NEXUS OS — Terminal CLI",
  description:
    "NEXUS OS governed multi-agent operating system — fallout-styled green terminal CLI. Query the brain (7352), inspect agents, vault, governor, swarm, tokens, models. CRT scanlines, phosphor themes, ASCII paint, mesh chat.",
  keywords: ["NEXUS OS", "terminal", "CLI", "governance", "AI OS", "retro", "CRT", "phosphor"],
  authors: [{ name: "sysop" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${mono.variable} antialiased bg-background text-foreground`}
        style={{ margin: 0, overflow: "hidden" }}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
