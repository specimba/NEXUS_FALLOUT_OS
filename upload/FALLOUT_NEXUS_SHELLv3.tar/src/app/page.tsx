'use client'

import dynamic from 'next/dynamic'

// Terminal manages its own window-level keyboard handling and Web Audio,
// so render it client-only to avoid SSR mismatches.
const Terminal = dynamic(() => import('@/components/os/Terminal'), { ssr: false })

export default function Home() {
  return <Terminal />
}
