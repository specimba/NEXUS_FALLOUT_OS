import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    "*.space-z.ai",
    "preview-chat-a9d92fa7-c39e-42cf-91c2-70688b629e08.space-z.ai",
  ],
};

export default nextConfig;
