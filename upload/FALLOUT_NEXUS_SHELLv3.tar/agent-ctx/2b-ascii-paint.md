# Task 2b — ASCII Paint Editor

Agent: full-stack-developer (ascii paint)
Task: Build the `paint` mode component for the retro CLI OS.

## Deliverable
- `src/components/os/AsciiPaint.tsx` — `'use client'` default export `AsciiPaint(props: ModeProps)`.

## Controls
| Key | Action |
|-----|--------|
| Arrow keys | Move cursor (clamped to grid bounds, key-repeat supported) |
| Space | Paint current cell with the active brush char |
| e / E | Erase current cell (set to space) |
| 1..9 | Select brush at index 0..8 |
| 0 | Select brush at index 9 (10th char) |
| c / C | Clear the whole canvas |
| s / S | Save canvas to VFS via `props.saveFile('sketch.txt', art)`; show transient "saved to <path>" status |
| Escape / q / Q | Quit — call `props.onExit(['[paint] session ended', ...art lines])` |

Modifier combos (Cmd/Ctrl/Alt) are ignored so browser/OS shortcuts pass through.

## Canvas
- Fixed geometry: **64 cols × 22 rows**.
- Font-size computed responsively from `window.innerWidth/Height`, clamped to 8–18px, so the grid always fits the viewport.
- Block cursor: overlay span with `background:theme.fg`, `color:theme.bg`, CSS blink ~1s (`paintBlink` keyframe, opacity 1→0).
- Painted cells get `textShadow: 0 0 6px theme.glow`; empty cells have no glow.

## Palette
`['█','▓','▒','░','#','*','+','.','/','\\']` (10 chars; `'0'` → index 9).

## State / data model
- `grid: useState<string[][]>` — immutable updates via `setCell` helper (clones the touched row). Task spec suggested `useRef` + tick, but the project's `react-hooks/refs` lint rule forbids reading `ref.current` during render; state is the idiomatic, lint-clean equivalent.
- `cursor: useState<{r,c}>`, `brush: useState<number>`, `status: useState<string>`, `viewport: useState<{w,h}>`.
- `statusTimerRef: useRef` for clearing the transient status message.

## Styling
- 100% inline styles for colors (theme is dynamic). No Tailwind color classes.
- Root: `position:absolute; inset:0; background:theme.bg; padding:12px; overflow:hidden; box-sizing:border-box; font-family: var(--font-mono), monospace;`
- Header line in `theme.dim`; footer palette line with active brush highlighted (`background:theme.fg`, `color:theme.bg`).

## Lint
`bun run lint` — exit code 0, no errors in AsciiPaint.tsx.
