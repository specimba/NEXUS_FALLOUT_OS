# Task 2a — full-stack-developer (weather api)

## Task
Build fake weather API route at `src/app/api/weather/route.ts`.

## Work Log
- Read shared `worklog.md` to confirm the project contract (monochrome terminal OS, Next 16 App Router, single `/` route, API routes used for backend).
- Inspected existing `src/app/api/route.ts` to match conventions (NextResponse from `next/server`).
- Created `src/app/api/weather/route.ts`:
  - `GET(req: Request)` reads optional `city` query param (default `"Neon City"`).
  - 8 fictional cities with per-city climate profiles (baseline temp + range); unknown cities fall back to a default profile.
  - Deterministic PRNG: FNV-1a hash of city name XOR (UTC hour * golden-ratio constant) -> mulberry32. Stable within an hour, drifts hour-to-hour.
  - Condition list mixes cyberpunk flavor ("Neon Drizzle", "Acid Mist", "Solar Flare", "Static Storm", "Toxic Smog", "Quantum Fog", "Magenta Snow", "Glitch Rain") with mundane ("Clear", "Cloudy", "Light Rain", "Haze", "Overcast", "Thunderstorm").
  - Computes tempC, feelsLikeC (temp adjusted by humidity + wind), humidity, windKph, windDir, visibilityKm, pressureHpa, uvIndex, sunrise/sunset (HH:MM), and a 3-day forecast (Tomorrow/+2/+3) each with its own seeded RNG.
  - Artificial 250ms delay via `await new Promise(r => setTimeout(r, 250))`.
  - Returns 200 with `Content-Type: application/json` using `NextResponse.json`.
  - Pure TypeScript, no external packages.
- Ran `bun run lint` — passed with no errors.

## Stage Summary
- Endpoint: `GET /api/weather?city=<name>` (defaults to Neon City).
- Response JSON shape:
```json
{
  "city": "Neon City",
  "fetchedAt": "ISO-8601 UTC",
  "tempC": 18,
  "feelsLikeC": 16,
  "condition": "Neon Drizzle",
  "humidity": 72,
  "windKph": 14,
  "windDir": "NW",
  "visibilityKm": 8,
  "pressureHpa": 1013,
  "uvIndex": 3,
  "sunrise": "06:42",
  "sunset": "19:18",
  "forecast": [
    { "day": "Tomorrow", "cond": "Acid Mist", "hi": 20, "lo": 12 },
    { "day": "+2", "cond": "Clear", "hi": 24, "lo": 14 },
    { "day": "+3", "cond": "Solar Flare", "hi": 29, "lo": 17 }
  ]
}
```
- Ready for the `weather` terminal command to `fetch('/api/weather?city=...')` and render the report.
