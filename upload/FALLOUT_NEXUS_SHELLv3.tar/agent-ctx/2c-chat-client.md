# Task 2c — ChatClient (fictional chat mode)

## File
- `src/components/os/ChatClient.tsx` — `'use client'`, default export `ChatClient(props: ModeProps)`.

## Contacts (4)
| id    | personality        | canned replies                                                                  |
|-------|--------------------|---------------------------------------------------------------------------------|
| nex   | terse hacker buddy | k. / on it. / lol / the uplink's noisy tonight / send me the dump / roger that  |
| vex   | conspiracy-minded  | they're watching the packets / tunnel through 7 proxies / trust no endpoint / i told you about the backdoor / stay frosty |
| mira  | friendly operator  | hey :)  / got the manifest / be careful out there / coffee's on me / talk soon  |
| orc   | bot/sysadmin       | /usr sector clean / daemon restarted / logs rotated / uptime 412 days / ack     |

## Layout
- Fullscreen `absolute inset-0`, `theme.bg`, monospace, `textShadow: 0 0 6px theme.glow`.
- Left sidebar (184px): `// contacts`, 4 rows `> ● handle  (unread)`, active row inverts fg/bg, hint block at bottom.
- Main pane: status bar (`handle — online` | `N msgs`), scrolling conversation, newest at bottom. Lines: `[HH:MM] handle > text` (timestamps dim), `you >` for own messages, dim italic `handle is typing…`.
- Bottom: input line `> <text>█` with a CSS-blinking block cursor (~1s). Text + cursor rendered by us; a transparent overlay `<input>` (auto-focused, refocuses on blur / any click) captures keystrokes.

## Interaction
- `Tab` — cycle to next contact. `1`–`4` — jump to a specific contact (only when input empty, so digits can still be typed mid-message).
- `Enter` — send (appends `you > msg`). Contact immediately shows `typing…` for 600–1600ms, then a canned reply (no immediate repeats). If you've switched away, unread bumps.
- `Up`/`Down` — recall sent-message history into the input.
- `:q` / `:quit` / `:exit` + Enter, `Escape`, or `Ctrl+C` — quit.
- `:s` / `:save` + Enter — save active transcript via `props.saveFile?.('chatlog.txt', …)`, prints a dim `[saved] <path>` system line.
- Global "alive" timer: every 4–9s a random online contact types briefly then sends an unsolicited line to their thread (unread bumps if not active).

## Quit behavior
`onExit(['[chat] session ended', 'conversation with nex: N messages', …])` — one line per contact (5 total, ≤8).

## Cleanup
All `setTimeout` ids stored in `timersRef` and cleared on unmount; `mountedRef` guards async callbacks.

## Lint
`ChatClient.tsx` passes ESLint cleanly (remaining repo errors are in `AsciiPaint.tsx`, a different task's file).
