# NEXUS-RESTORE — NEXUS OS brain + CLI + API restoration

Agent: full-stack-developer (NEXUS restore)
Task ID: NEXUS-RESTORE
Scope: rebuild the entire NEXUS governance layer (brain, CLI commands, API routes) after a server crash.

## Files created

- `src/lib/nexus/brain.ts` — in-memory governance brain (~660 lines). Seeded PRNG (FNV-1a → mulberry32) with a fixed BOOT_EPOCH salt + session-boot stamp so data is stable within a session. Exports: `getStatus`, `getAgents`, `getAgent`, `getVault`, `getGovernor`, `getSwarm`, `getTokens`, `getModels`, `getRelay`, `getCompliance`, `getProposals`, `getVap`, `getLogs`, `getTrust`, `getPorts`, `getCost`, `getDoctor`, `getScan`, `getConstitution`, `getWiki`, `getWeaver`, `getDrillScoreboard`, `runDrill`, `getModalStatus`, `getRecentContext`, `resetBrain`. Strongly-typed (no `any`); all entity interfaces exported.
- `src/lib/nexus/zai-shared.ts` — lazy dynamic `import('z-ai-web-dev-sdk')` loader. The SDK only loads when `callZaiDirect` is first called (i.e. when the `ask` route fires). Exports `callZaiDirect(messages, opts)` and `resetZai()`.
- `src/lib/os/nexus-commands.ts` — 40 NEXUS CLI commands. Read-only commands call brain getters directly and render ASCII boxes/tables/bars. Mutation commands (intervene / halt / propose / spawn / appeal / trust-update / handoff) POST to the corresponding API route and format the ack. Live commands (tail / top / watch) use the new `ctx.pushLine` + `ctx.registerStop` + `CommandResult.live` flag, with a 1.4–1.6s polling interval and a 200–300 tick safety stop. Exports `NEXUS_COMMANDS: Record<string, CommandDef>`.

## Files modified

- `src/lib/os/commands.ts` — added `import { NEXUS_COMMANDS }` and spread `...NEXUS_COMMANDS` into the `COMMANDS` registry. Extended `CommandContext` with `pushLine(line)` and `registerStop(fn)`; added `live?: boolean` to `CommandResult`.
- `src/components/os/Terminal.tsx` — wired the new context fields: `liveStopRef` holds the registered stop fn; `buildCtx` provides `pushLine` (forwards to `pushLines`) and `registerStop` (stores into `liveStopRef`). `execute` calls any prior `liveStopRef.current?.()` before starting a new command, keeps `busy=true` when `res.live` is set, and only clears busy in `finally` if no live stop is registered. The Ctrl+C handler now interrupts a running live command (calls the stop fn, clears busy, prints `^C — live command stopped`).

## API routes (25)

All under `src/app/api/nexus/<name>/route.ts`. Each is a thin handler over a brain getter (or a synthetic ack for mutations), with a 120–180 ms artificial delay and a `try/catch → 500`. Uses `NextResponse.json`.

GET only: status, vault, tokens, models, relay, compliance, logs, ports, cost, doctor, scan, constitution, wiki, weaver
GET + POST: agents (spawn), governor (appeal), swarm (dispatch / probe / handoff), proposals (create / approve / reject), vap (verify), trust (update), drill (run), modal (run)
POST only: intervene, halt, ask (uses `callZaiDirect` from `@/lib/nexus/zai-shared`; sends the recent-context JSON as the system prompt; returns `{ answer, model, elapsedMs, ts }`)

## Lint

`bun run lint` passes with zero errors after every file. Final run: clean.

## Verification

- `GET /` 200 (page renders, no console errors).
- All 25 GET routes return 200 with realistic JSON.
- All POST mutations return 200 with `{ ok: true, vapHash, ts, ... }` acks.
- `POST /api/nexus/ask` with `{"question":"What is the current token usage?"}` returned a 3-sentence answer from GLM-5.2 that correctly cited `73500 / 100000 (73.5%)` and the per-track vault counts — confirming the lazy SDK loader works and the recent-context prompt is being honored.
- `dev.log` shows only `GET / 200` and `GET /api/nexus/* 200` entries; no compile errors after the initial hot-reload race resolved.
